package org.openapitools.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import java.math.BigDecimal;
import org.springframework.lang.Nullable;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * InsurancePlanFields
 */

@JsonTypeName("InsurancePlan-Fields")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2025-10-12T06:22:58.239361900-04:00[America/New_York]", comments = "Generator version: 7.15.0")
public class InsurancePlanFields {

  private @Nullable String name;

  private @Nullable BigDecimal deductibleInNetwork;

  private @Nullable BigDecimal deductibleOutOfNetwork;

  public InsurancePlanFields name(@Nullable String name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
   */
  
  @Schema(name = "name", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("name")
  public @Nullable String getName() {
    return name;
  }

  public void setName(@Nullable String name) {
    this.name = name;
  }

  public InsurancePlanFields deductibleInNetwork(@Nullable BigDecimal deductibleInNetwork) {
    this.deductibleInNetwork = deductibleInNetwork;
    return this;
  }

  /**
   * Get deductibleInNetwork
   * @return deductibleInNetwork
   */
  @Valid 
  @Schema(name = "deductibleInNetwork", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("deductibleInNetwork")
  public @Nullable BigDecimal getDeductibleInNetwork() {
    return deductibleInNetwork;
  }

  public void setDeductibleInNetwork(@Nullable BigDecimal deductibleInNetwork) {
    this.deductibleInNetwork = deductibleInNetwork;
  }

  public InsurancePlanFields deductibleOutOfNetwork(@Nullable BigDecimal deductibleOutOfNetwork) {
    this.deductibleOutOfNetwork = deductibleOutOfNetwork;
    return this;
  }

  /**
   * Get deductibleOutOfNetwork
   * @return deductibleOutOfNetwork
   */
  @Valid 
  @Schema(name = "deductibleOutOfNetwork", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("deductibleOutOfNetwork")
  public @Nullable BigDecimal getDeductibleOutOfNetwork() {
    return deductibleOutOfNetwork;
  }

  public void setDeductibleOutOfNetwork(@Nullable BigDecimal deductibleOutOfNetwork) {
    this.deductibleOutOfNetwork = deductibleOutOfNetwork;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InsurancePlanFields insurancePlanFields = (InsurancePlanFields) o;
    return Objects.equals(this.name, insurancePlanFields.name) &&
        Objects.equals(this.deductibleInNetwork, insurancePlanFields.deductibleInNetwork) &&
        Objects.equals(this.deductibleOutOfNetwork, insurancePlanFields.deductibleOutOfNetwork);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, deductibleInNetwork, deductibleOutOfNetwork);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InsurancePlanFields {\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    deductibleInNetwork: ").append(toIndentedString(deductibleInNetwork)).append("\n");
    sb.append("    deductibleOutOfNetwork: ").append(toIndentedString(deductibleOutOfNetwork)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

