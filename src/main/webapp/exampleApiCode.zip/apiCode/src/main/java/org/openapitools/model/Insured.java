package org.openapitools.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.openapitools.model.Location;
import org.springframework.lang.Nullable;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * 
 */

@Schema(name = "Insured", description = "")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2025-10-12T06:22:58.239361900-04:00[America/New_York]", comments = "Generator version: 7.15.0")
public class Insured {

  private @Nullable String email;

  private @Nullable String nameFirst;

  private @Nullable String nameLast;

  private @Nullable String phone;

  private @Nullable Location location;

  @Valid
  private List<String> enrolled = new ArrayList<>();

  public Insured email(@Nullable String email) {
    this.email = email;
    return this;
  }

  /**
   * Get email
   * @return email
   */
  
  @Schema(name = "email", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("email")
  public @Nullable String getEmail() {
    return email;
  }

  public void setEmail(@Nullable String email) {
    this.email = email;
  }

  public Insured nameFirst(@Nullable String nameFirst) {
    this.nameFirst = nameFirst;
    return this;
  }

  /**
   * Get nameFirst
   * @return nameFirst
   */
  
  @Schema(name = "nameFirst", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("nameFirst")
  public @Nullable String getNameFirst() {
    return nameFirst;
  }

  public void setNameFirst(@Nullable String nameFirst) {
    this.nameFirst = nameFirst;
  }

  public Insured nameLast(@Nullable String nameLast) {
    this.nameLast = nameLast;
    return this;
  }

  /**
   * Get nameLast
   * @return nameLast
   */
  
  @Schema(name = "nameLast", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("nameLast")
  public @Nullable String getNameLast() {
    return nameLast;
  }

  public void setNameLast(@Nullable String nameLast) {
    this.nameLast = nameLast;
  }

  public Insured phone(@Nullable String phone) {
    this.phone = phone;
    return this;
  }

  /**
   * Get phone
   * @return phone
   */
  
  @Schema(name = "phone", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("phone")
  public @Nullable String getPhone() {
    return phone;
  }

  public void setPhone(@Nullable String phone) {
    this.phone = phone;
  }

  public Insured location(@Nullable Location location) {
    this.location = location;
    return this;
  }

  /**
   * Get location
   * @return location
   */
  @Valid 
  @Schema(name = "location", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("location")
  public @Nullable Location getLocation() {
    return location;
  }

  public void setLocation(@Nullable Location location) {
    this.location = location;
  }

  public Insured enrolled(List<String> enrolled) {
    this.enrolled = enrolled;
    return this;
  }

  public Insured addEnrolledItem(String enrolledItem) {
    if (this.enrolled == null) {
      this.enrolled = new ArrayList<>();
    }
    this.enrolled.add(enrolledItem);
    return this;
  }

  /**
   * Get enrolled
   * @return enrolled
   */
  
  @Schema(name = "enrolled", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("enrolled")
  public List<String> getEnrolled() {
    return enrolled;
  }

  public void setEnrolled(List<String> enrolled) {
    this.enrolled = enrolled;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Insured insured = (Insured) o;
    return Objects.equals(this.email, insured.email) &&
        Objects.equals(this.nameFirst, insured.nameFirst) &&
        Objects.equals(this.nameLast, insured.nameLast) &&
        Objects.equals(this.phone, insured.phone) &&
        Objects.equals(this.location, insured.location) &&
        Objects.equals(this.enrolled, insured.enrolled);
  }

  @Override
  public int hashCode() {
    return Objects.hash(email, nameFirst, nameLast, phone, location, enrolled);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Insured {\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    nameFirst: ").append(toIndentedString(nameFirst)).append("\n");
    sb.append("    nameLast: ").append(toIndentedString(nameLast)).append("\n");
    sb.append("    phone: ").append(toIndentedString(phone)).append("\n");
    sb.append("    location: ").append(toIndentedString(location)).append("\n");
    sb.append("    enrolled: ").append(toIndentedString(enrolled)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

