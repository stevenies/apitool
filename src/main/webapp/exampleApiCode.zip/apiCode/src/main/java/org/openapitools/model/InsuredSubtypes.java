package org.openapitools.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import org.openapitools.model.Dependent;
import org.openapitools.model.Subscriber;
import org.springframework.lang.Nullable;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * InsuredSubtypes
 */

@JsonTypeName("Insured-Subtypes")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2025-10-12T06:22:58.239361900-04:00[America/New_York]", comments = "Generator version: 7.15.0")
public class InsuredSubtypes {

  private @Nullable String email;

  private @Nullable String nameFirst;

  private @Nullable String nameLast;

  private @Nullable String phone;

  public InsuredSubtypes email(@Nullable String email) {
    this.email = email;
    return this;
  }

  /**
   * Get email
   * @return email
   */
  
  @Schema(name = "email", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("email")
  public @Nullable String getEmail() {
    return email;
  }

  public void setEmail(@Nullable String email) {
    this.email = email;
  }

  public InsuredSubtypes nameFirst(@Nullable String nameFirst) {
    this.nameFirst = nameFirst;
    return this;
  }

  /**
   * Get nameFirst
   * @return nameFirst
   */
  
  @Schema(name = "nameFirst", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("nameFirst")
  public @Nullable String getNameFirst() {
    return nameFirst;
  }

  public void setNameFirst(@Nullable String nameFirst) {
    this.nameFirst = nameFirst;
  }

  public InsuredSubtypes nameLast(@Nullable String nameLast) {
    this.nameLast = nameLast;
    return this;
  }

  /**
   * Get nameLast
   * @return nameLast
   */
  
  @Schema(name = "nameLast", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("nameLast")
  public @Nullable String getNameLast() {
    return nameLast;
  }

  public void setNameLast(@Nullable String nameLast) {
    this.nameLast = nameLast;
  }

  public InsuredSubtypes phone(@Nullable String phone) {
    this.phone = phone;
    return this;
  }

  /**
   * Get phone
   * @return phone
   */
  
  @Schema(name = "phone", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("phone")
  public @Nullable String getPhone() {
    return phone;
  }

  public void setPhone(@Nullable String phone) {
    this.phone = phone;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InsuredSubtypes insuredSubtypes = (InsuredSubtypes) o;
    return Objects.equals(this.email, insuredSubtypes.email) &&
        Objects.equals(this.nameFirst, insuredSubtypes.nameFirst) &&
        Objects.equals(this.nameLast, insuredSubtypes.nameLast) &&
        Objects.equals(this.phone, insuredSubtypes.phone);
  }

  @Override
  public int hashCode() {
    return Objects.hash(email, nameFirst, nameLast, phone);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InsuredSubtypes {\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    nameFirst: ").append(toIndentedString(nameFirst)).append("\n");
    sb.append("    nameLast: ").append(toIndentedString(nameLast)).append("\n");
    sb.append("    phone: ").append(toIndentedString(phone)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

