package org.openapitools.api;

import org.openapitools.model.Dependent;
import org.openapitools.model.DependentArrayPaged;
import org.openapitools.model.ErrorInfo;
import org.openapitools.model.JsonPatch;
import org.openapitools.model.Subscriber;
import org.openapitools.model.SubscriberArrayPaged;
import org.openapitools.model.SubscriberFields;
import org.openapitools.model.ValidationErrorInfo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.lang.Nullable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.context.request.NativeWebRequest;

import jakarta.validation.constraints.*;
import jakarta.validation.Valid;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import jakarta.annotation.Generated;

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2025-10-12T06:22:58.239361900-04:00[America/New_York]", comments = "Generator version: 7.15.0")
@Controller
@RequestMapping("${openapi.insuranceExample.base-path:/insurance-v1.0}")
public class SubscriberApiController implements SubscriberApi {

    private final NativeWebRequest request;

    @Autowired
    public SubscriberApiController(NativeWebRequest request) {
        this.request = request;
    }

    @Override
    public Optional<NativeWebRequest> getRequest() {
        return Optional.ofNullable(request);
    }

}
