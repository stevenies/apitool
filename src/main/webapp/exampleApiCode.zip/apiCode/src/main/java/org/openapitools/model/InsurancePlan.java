package org.openapitools.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.openapitools.model.BenefitSet;
import org.springframework.lang.Nullable;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * 
 */

@Schema(name = "InsurancePlan", description = "")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2025-10-12T06:22:58.239361900-04:00[America/New_York]", comments = "Generator version: 7.15.0")
public class InsurancePlan {

  private @Nullable String name;

  private @Nullable BigDecimal deductibleInNetwork;

  private @Nullable BigDecimal deductibleOutOfNetwork;

  @Valid
  private List<@Valid BenefitSet> benefitSet = new ArrayList<>();

  public InsurancePlan name(@Nullable String name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
   */
  
  @Schema(name = "name", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("name")
  public @Nullable String getName() {
    return name;
  }

  public void setName(@Nullable String name) {
    this.name = name;
  }

  public InsurancePlan deductibleInNetwork(@Nullable BigDecimal deductibleInNetwork) {
    this.deductibleInNetwork = deductibleInNetwork;
    return this;
  }

  /**
   * Get deductibleInNetwork
   * @return deductibleInNetwork
   */
  @Valid 
  @Schema(name = "deductibleInNetwork", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("deductibleInNetwork")
  public @Nullable BigDecimal getDeductibleInNetwork() {
    return deductibleInNetwork;
  }

  public void setDeductibleInNetwork(@Nullable BigDecimal deductibleInNetwork) {
    this.deductibleInNetwork = deductibleInNetwork;
  }

  public InsurancePlan deductibleOutOfNetwork(@Nullable BigDecimal deductibleOutOfNetwork) {
    this.deductibleOutOfNetwork = deductibleOutOfNetwork;
    return this;
  }

  /**
   * Get deductibleOutOfNetwork
   * @return deductibleOutOfNetwork
   */
  @Valid 
  @Schema(name = "deductibleOutOfNetwork", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("deductibleOutOfNetwork")
  public @Nullable BigDecimal getDeductibleOutOfNetwork() {
    return deductibleOutOfNetwork;
  }

  public void setDeductibleOutOfNetwork(@Nullable BigDecimal deductibleOutOfNetwork) {
    this.deductibleOutOfNetwork = deductibleOutOfNetwork;
  }

  public InsurancePlan benefitSet(List<@Valid BenefitSet> benefitSet) {
    this.benefitSet = benefitSet;
    return this;
  }

  public InsurancePlan addBenefitSetItem(BenefitSet benefitSetItem) {
    if (this.benefitSet == null) {
      this.benefitSet = new ArrayList<>();
    }
    this.benefitSet.add(benefitSetItem);
    return this;
  }

  /**
   * Get benefitSet
   * @return benefitSet
   */
  @Valid 
  @Schema(name = "benefitSet", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("benefitSet")
  public List<@Valid BenefitSet> getBenefitSet() {
    return benefitSet;
  }

  public void setBenefitSet(List<@Valid BenefitSet> benefitSet) {
    this.benefitSet = benefitSet;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InsurancePlan insurancePlan = (InsurancePlan) o;
    return Objects.equals(this.name, insurancePlan.name) &&
        Objects.equals(this.deductibleInNetwork, insurancePlan.deductibleInNetwork) &&
        Objects.equals(this.deductibleOutOfNetwork, insurancePlan.deductibleOutOfNetwork) &&
        Objects.equals(this.benefitSet, insurancePlan.benefitSet);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, deductibleInNetwork, deductibleOutOfNetwork, benefitSet);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InsurancePlan {\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    deductibleInNetwork: ").append(toIndentedString(deductibleInNetwork)).append("\n");
    sb.append("    deductibleOutOfNetwork: ").append(toIndentedString(deductibleOutOfNetwork)).append("\n");
    sb.append("    benefitSet: ").append(toIndentedString(benefitSet)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

