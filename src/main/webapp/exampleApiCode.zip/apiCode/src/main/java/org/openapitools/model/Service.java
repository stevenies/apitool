package org.openapitools.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import org.springframework.lang.Nullable;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * 
 */

@Schema(name = "Service", description = "")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2025-10-12T06:22:58.239361900-04:00[America/New_York]", comments = "Generator version: 7.15.0")
public class Service {

  private @Nullable String name;

  private @Nullable BigDecimal costInNetwork;

  private @Nullable BigDecimal costOutOfNetwork;

  public Service name(@Nullable String name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
   */
  
  @Schema(name = "name", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("name")
  public @Nullable String getName() {
    return name;
  }

  public void setName(@Nullable String name) {
    this.name = name;
  }

  public Service costInNetwork(@Nullable BigDecimal costInNetwork) {
    this.costInNetwork = costInNetwork;
    return this;
  }

  /**
   * Get costInNetwork
   * @return costInNetwork
   */
  @Valid 
  @Schema(name = "costInNetwork", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("costInNetwork")
  public @Nullable BigDecimal getCostInNetwork() {
    return costInNetwork;
  }

  public void setCostInNetwork(@Nullable BigDecimal costInNetwork) {
    this.costInNetwork = costInNetwork;
  }

  public Service costOutOfNetwork(@Nullable BigDecimal costOutOfNetwork) {
    this.costOutOfNetwork = costOutOfNetwork;
    return this;
  }

  /**
   * Get costOutOfNetwork
   * @return costOutOfNetwork
   */
  @Valid 
  @Schema(name = "costOutOfNetwork", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("costOutOfNetwork")
  public @Nullable BigDecimal getCostOutOfNetwork() {
    return costOutOfNetwork;
  }

  public void setCostOutOfNetwork(@Nullable BigDecimal costOutOfNetwork) {
    this.costOutOfNetwork = costOutOfNetwork;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Service service = (Service) o;
    return Objects.equals(this.name, service.name) &&
        Objects.equals(this.costInNetwork, service.costInNetwork) &&
        Objects.equals(this.costOutOfNetwork, service.costOutOfNetwork);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, costInNetwork, costOutOfNetwork);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Service {\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    costInNetwork: ").append(toIndentedString(costInNetwork)).append("\n");
    sb.append("    costOutOfNetwork: ").append(toIndentedString(costOutOfNetwork)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

