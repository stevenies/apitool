package org.openapitools.model;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonTypeName;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.openapitools.model.Dependent;
import org.springframework.lang.Nullable;
import org.openapitools.jackson.nullable.JsonNullable;
import java.time.OffsetDateTime;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * DependentArrayPaged
 */

@JsonTypeName("Dependent-ArrayPaged")
@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2025-10-12T06:22:58.239361900-04:00[America/New_York]", comments = "Generator version: 7.15.0")
public class DependentArrayPaged {

  private @Nullable Integer pageIndex;

  private @Nullable Integer totalPages;

  @Valid
  private List<@Valid Dependent> items = new ArrayList<>();

  public DependentArrayPaged pageIndex(@Nullable Integer pageIndex) {
    this.pageIndex = pageIndex;
    return this;
  }

  /**
   * Get pageIndex
   * @return pageIndex
   */
  
  @Schema(name = "pageIndex", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("pageIndex")
  public @Nullable Integer getPageIndex() {
    return pageIndex;
  }

  public void setPageIndex(@Nullable Integer pageIndex) {
    this.pageIndex = pageIndex;
  }

  public DependentArrayPaged totalPages(@Nullable Integer totalPages) {
    this.totalPages = totalPages;
    return this;
  }

  /**
   * Get totalPages
   * @return totalPages
   */
  
  @Schema(name = "totalPages", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("totalPages")
  public @Nullable Integer getTotalPages() {
    return totalPages;
  }

  public void setTotalPages(@Nullable Integer totalPages) {
    this.totalPages = totalPages;
  }

  public DependentArrayPaged items(List<@Valid Dependent> items) {
    this.items = items;
    return this;
  }

  public DependentArrayPaged addItemsItem(Dependent itemsItem) {
    if (this.items == null) {
      this.items = new ArrayList<>();
    }
    this.items.add(itemsItem);
    return this;
  }

  /**
   * Get items
   * @return items
   */
  @Valid 
  @Schema(name = "items", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
  @JsonProperty("items")
  public List<@Valid Dependent> getItems() {
    return items;
  }

  public void setItems(List<@Valid Dependent> items) {
    this.items = items;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DependentArrayPaged dependentArrayPaged = (DependentArrayPaged) o;
    return Objects.equals(this.pageIndex, dependentArrayPaged.pageIndex) &&
        Objects.equals(this.totalPages, dependentArrayPaged.totalPages) &&
        Objects.equals(this.items, dependentArrayPaged.items);
  }

  @Override
  public int hashCode() {
    return Objects.hash(pageIndex, totalPages, items);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DependentArrayPaged {\n");
    sb.append("    pageIndex: ").append(toIndentedString(pageIndex)).append("\n");
    sb.append("    totalPages: ").append(toIndentedString(totalPages)).append("\n");
    sb.append("    items: ").append(toIndentedString(items)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

